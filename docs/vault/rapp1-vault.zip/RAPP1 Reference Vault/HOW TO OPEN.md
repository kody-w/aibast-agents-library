# RAPP/1 Reference Vault

This folder is an Obsidian vault.

1. Unzip it.
2. In Obsidian choose **Open folder as vault** and pick this folder.
3. Start at README.md. Wikilinks, search and the graph work with no plugins.

Read it in the browser at https://microsoft.github.io/aibast-agents-library/docs/vault/
