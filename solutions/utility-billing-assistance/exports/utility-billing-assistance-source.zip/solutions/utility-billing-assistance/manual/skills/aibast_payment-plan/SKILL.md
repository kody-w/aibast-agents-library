---
name: utility-billing-assistance-payment-plan
description: Use when a Revenue Services Supervisor asks to draft installment options without account changes.
---
# Utility Billing and Assistance Agent: Payment Plan

## Route

Use the `payment_plan` operation. The canonical persona prompt is:

> Show ACCT-90003 payment-plan options, but do not set one up.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `payment_plan` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- 12 months
- No payment arrangement was created

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
