---
name: utility-billing-assistance-assistance-programs
description: Use when a Assistance Coordinator asks to perform preliminary, non-binding program screening.
---
# Utility Billing and Assistance Agent: Assistance Programs

## Route

Use the `assistance_programs` operation. The canonical persona prompt is:

> Screen a two-person household earning 25000 with a 70-year-old applicant.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `assistance_programs` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- POTENTIALLY ELIGIBLE
- No eligibility determination
- enrollment

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
