---
name: draft-response
description: "Use when an officer asks for a draft reply that answers every question with citations."
---
# Cited draft reply

Use when an officer asks for a draft reply that answers every question with citations.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `DRAFT, NOT SENT`
- `OFFICER TO DEVELOP`
- `No email was sent`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
