---
name: claim-intake
description: Use for claims intake triage questions in the Claims Processing Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Claims intake triage

Summarizes fictional claims by loss, amount, status, and fraud-review score.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Claims Operations Leader

Prompt: Process the incoming claims queue and identify which ones need immediate attention vs auto-adjudication.

Expected synthetic evidence: 2,847, 1,936, 34 claims with regulatory deadlines.
