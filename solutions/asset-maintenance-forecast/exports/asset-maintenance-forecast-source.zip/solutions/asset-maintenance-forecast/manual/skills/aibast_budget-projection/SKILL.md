---
name: asset-maintenance-forecast-budget-projection
description: Use when a Finance Business Partner asks to prepare a non-binding maintenance budget estimate.
---
# Asset Maintenance Forecast Agent: Budget Projection

## Route

Use the `budget_projection` operation. The canonical persona prompt is:

> What maintenance funding should I reserve for the transformer risk?

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `budget_projection` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Substation Transformer B-12
- $273,000
- Synthetic planning estimate

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
