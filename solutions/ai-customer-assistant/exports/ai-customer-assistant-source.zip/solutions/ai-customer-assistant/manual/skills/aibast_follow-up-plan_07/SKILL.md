---
name: follow-up-plan
description: "Use when a back-office agent asks something like \"Schedule the follow-up for Jennifer Adams and prepare the response email\""
---
<!-- bic:source=blank -->
# Follow up plan

Use when a back-office agent asks something like "Schedule the follow-up for Jennifer Adams and prepare the response email"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `+24 hours`
- `Your Account Corrected - Refund Processed`
- `ready for you to send`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
