---
name: handle-inquiry
description: Use when a back-office agent asks what is happening on a specific case and what should be reviewed next.
---
<!-- bic:source=blank -->
# Inquiry triage brief

Use when a back-office agent asks what is happening on a specific case and what should be reviewed next.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `INQ-4001`
- `KB-104`
- `Tier 1 Technical Support`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
