---
name: satisfaction-survey
description: Use when a quality analyst asks for the fictional CSAT distribution and recurring service themes.
---
<!-- bic:source=blank -->
# Quality and satisfaction review

Use when a quality analyst asks for the fictional CSAT distribution and recurring service themes.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.
5. Use the exact heading `Recent Surveys` and preserve the exact score format `4.3/5.0`.
6. State that the evidence comes from `fictional pilot records`.

## Deterministic pilot evidence

- `Customer Satisfaction Dashboard`
- `4.3/5.0`
- `Recent Surveys`
- `fictional pilot records`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
