---
name: morning-summary
description: "Use when a fraud operations manager asks something like \"Yes, summarize everything and give me the action items\""
---
<!-- bic:source=blank -->
# Morning summary

Use when a fraud operations manager asks something like "Yes, summarize everything and give me the action items"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `$691K`
- `SAR filing`
- `1,247`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
