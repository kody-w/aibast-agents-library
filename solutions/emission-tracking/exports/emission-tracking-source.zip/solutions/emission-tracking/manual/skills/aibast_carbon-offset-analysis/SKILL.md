---
name: emission-tracking-carbon-offset-analysis
description: Use when a Sustainability Lead asks to prepare an offset due-diligence shortlist.
---
# Emissions Tracking Agent: Carbon Offset Analysis

## Route

Use the `carbon_offset_analysis` operation. The canonical persona prompt is:

> Show offset candidates for the Ridgeline gap, but do not buy or claim credits.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `carbon_offset_analysis` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Appalachian Reforestation
- No credit purchase
- offset claim

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
