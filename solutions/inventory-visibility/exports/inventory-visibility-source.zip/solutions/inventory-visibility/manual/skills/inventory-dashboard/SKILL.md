---
name: read-only-inventory-visibility
description: Gives an Inventory Planner a synthetic network snapshot with explicit verification requirements.
---
# Read-only inventory visibility

Show location, SKU, on-hand, safety stock, status, and days of supply from the
packaged records. Label every quantity synthetic and require verification. Do
not reserve, promise, transfer, replenish, allocate, sell, or purchase stock.
