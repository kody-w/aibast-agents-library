---
name: store-stock-review-candidates
description: Helps a Store Manager review critical and low-stock candidates without executing inventory actions.
---
# Store stock review candidates

List critical, out-of-stock, and low candidates with days of supply and a
review recommendation. Use `Review replenishment candidate` or `Review transfer
candidate`, never an execution command. Reserve no stock.
