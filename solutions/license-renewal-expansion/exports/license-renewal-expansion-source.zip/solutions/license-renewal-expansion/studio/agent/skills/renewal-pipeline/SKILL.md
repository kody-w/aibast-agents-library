---
name: license-renewal-expansion-renewal-pipeline
description: Review the synthetic renewal pipeline and risk bands without changing CRM or forecast records.
---

# License Renewal and Expansion Agent — Renewal Pipeline

## Persona
Sales Leadership

## Input contract
- Operation: `renewal_pipeline`
- Data source: `synthetic` only
- Use only the workshop's SharePoint list tools and the uploaded rules knowledge.

## Guardrails
- Use only the fixed synthetic snapshot from the workshop's list tools and rules knowledge; do not browse, enrich, infer, invent, or use other data.
- Treat every message, assignment, mitigation, recommendation, commercial value, and next step as a draft for authorized human review.
- Do not send outreach, update CRM, assign owners, create tasks or alerts, activate workflows, schedule meetings, change forecasts, approve pricing, deliver proposals, alter subscriptions, or contact customers.

## Procedure
1. Confirm that the request matches `renewal_pipeline`.
2. Read the records with the SharePoint list tools, and the rules and controls knowledge.
3. Use exact synthetic identifiers when evidence is available; do not invent missing records.
4. Produce the exact fixed-snapshot evidence with the required `Renewal Pipeline`, `Draft Renewal Preparation Checklist`, `Evidence boundary` anchors.
5. End with the evidence boundary below.

## Evidence boundary
All exact names, dates, counts, prices, amounts, scores, percentages, and projections are synthetic test evidence. The response is read-only decision support. Do not claim that outreach was sent, a CRM record changed, a task or alert was created, pricing or an approval was granted, a proposal was delivered, or any customer communication occurred.

## Locked demo prompt
Review the list-backed synthetic renewal pipeline, risk bands, and preparation checklist without changing CRM or forecast records.

## Expected evidence marker
The response must include `Renewal Pipeline`, `Draft Renewal Preparation Checklist`, `Evidence boundary` and preserve the explicit synthetic evidence boundary.
