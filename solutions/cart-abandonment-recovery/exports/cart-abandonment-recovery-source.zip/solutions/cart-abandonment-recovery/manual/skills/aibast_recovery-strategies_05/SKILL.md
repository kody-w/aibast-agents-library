---
name: recovery-strategies
description: "Use when a marketing manager asks something like \"As Marketing Manager, what personalized offers should we make to win back our top abandoned-cart shoppers\""
---
<!-- bic:source=blank -->
# Recovery strategies

Use when a marketing manager asks something like "As Marketing Manager, what personalized offers should we make to win back our top abandoned-cart shoppers"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Personalized Recovery Strategies`
- `Sarah M.`
- `Point Expiry (12,000)`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
