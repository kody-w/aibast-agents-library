---
name: financial-impact
description: "Use when a supply chain director asks something like \"What would those mitigations cost us, and is the investment worth it\""
---
<!-- bic:source=blank -->
# Financial impact

Use when a supply chain director asks something like "What would those mitigations cost us, and is the investment worth it"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `$1.098M`
- `65% reduction`
- `Break-even`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

## Locked validation case

- Persona: **Supply Chain Director**
- Prompt: “What would those mitigations cost us, and is the investment worth it?”
- Required deterministic evidence: `$1.098M`, `65% reduction`, `Break-even`

## Authorization boundary

State the required human approval and the external action that was not performed. Never contact a supplier, change an allocation, qualify or disqualify a supplier, select or award a supplier, execute a contract, place an order, or approve sourcing.
