---
name: monitoring-plan
description: "Use when a procurement manager asks something like \"How would we keep watching these suppliers after the plan is in place\""
---
<!-- bic:source=blank -->
# Monitoring plan

Use when a procurement manager asks something like "How would we keep watching these suppliers after the plan is in place"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Alert Thresholds`
- `Automated Actions`
- `Early warning`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

## Locked validation case

- Persona: **Procurement Manager**
- Prompt: “How would we keep watching these suppliers after the plan is in place?”
- Required deterministic evidence: `Alert Thresholds`, `Automated Actions`, `Early warning`

## Authorization boundary

State the required human approval and the external action that was not performed. Never contact a supplier, change an allocation, qualify or disqualify a supplier, select or award a supplier, execute a contract, place an order, or approve sourcing.
