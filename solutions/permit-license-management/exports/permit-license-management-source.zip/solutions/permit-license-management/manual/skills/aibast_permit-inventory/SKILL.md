---
name: permit-license-management-permit-inventory
description: Use when a Facility Manager asks to review the synthetic permit register by facility.
---
# Permit Management Agent: Permit Inventory

## Route

Use the `permit_inventory` operation. The canonical persona prompt is:

> Which Riverside permit is expired right now?

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `permit_inventory` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- PRM-6002
- EXPIRED
- Verify status

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
