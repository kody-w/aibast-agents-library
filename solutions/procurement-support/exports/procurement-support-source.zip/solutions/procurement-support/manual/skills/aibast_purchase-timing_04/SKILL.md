---
name: purchase-timing
description: "Use when someone asks for the implementation plan, deadlines, and savings at risk."
---
<!-- bic:source=blank -->
# Purchase-timing brief

Use when someone asks for the implementation plan, deadlines, and savings at risk.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `PO-2024-Q1-0234`
- `$21,760`
- `No supplier is selected`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
