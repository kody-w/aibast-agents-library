---
name: purchase-timing
description: Use when a category buyer asks how to sequence review of renewals, volume tiers, and announced price changes.
---
<!-- bic:source=blank -->
# Purchase-timing brief

Use when a category buyer asks how to sequence review of renewals, volume tiers, and announced price changes.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Northstar Imaging`
- `MedSupply Cooperative`
- `CareTech Devices`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
