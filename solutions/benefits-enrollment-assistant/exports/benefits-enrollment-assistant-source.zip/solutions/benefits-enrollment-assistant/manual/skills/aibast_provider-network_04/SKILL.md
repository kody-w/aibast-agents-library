---
name: provider-network
description: "Use when an employee asks whether their doctors or clinics are in network on each plan."
---
# Provider network check

Use when an employee asks whether their doctors or clinics are in network on each plan.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `BE-04`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Riverbend Pediatrics`
- `Out of network`
- `Network gaps`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
