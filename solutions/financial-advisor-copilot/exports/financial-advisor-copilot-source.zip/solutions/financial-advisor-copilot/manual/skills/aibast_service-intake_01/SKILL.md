---
name: service-intake
description: Use for service intake and routing questions in the Financial Advisor Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Service intake and routing

Prepares check-in, identity-control status, request, and proposed routing without verification or assignment.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Branch Banker

Prompt: Who is waiting, what do they need, and where should I route them after identity checks?

Expected synthetic evidence: CLI-3001, No identity.
