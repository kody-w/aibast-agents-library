---
name: flagged-review
description: "Use when a billing manager asks something like \"Break down the hours that were flagged for review before final approval\""
---
<!-- bic:source=blank -->
# Flagged review

Use when a billing manager asks something like "Break down the hours that were flagged for review before final approval"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `MegaCorp Systems`
- `$892K`
- `5 projects over 95% budget consumed`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
