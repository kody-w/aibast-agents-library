---
name: account-intelligence-stakeholder-map
description: Map the synthetic buying committee and relationship gaps without creating outreach tasks.
---

# Account Intelligence Agent — Stakeholder Map

## Persona
Account Executive

## Input contract
- Operation: `stakeholder_map`
- Data source: `synthetic` only
- Use only the two uploaded knowledge files in this package.

## Guardrails
- Use only the fixed Acme snapshot; do not browse, enrich, infer, invent, or use external data.
- Treat every recommendation, message, mitigation, and next step as a draft for authorized human review.
- Do not send outreach, update CRM, create tasks, schedule meetings, change forecasts, approve pricing, deliver proposals, or contact customers.

## Procedure
1. Confirm that the request matches `stakeholder_map`.
2. Read the synthetic records and operating rules before analyzing.
3. Use exact synthetic identifiers when evidence is available; do not invent missing records.
4. Emit the complete Acme stakeholder evidence with the exact `Stakeholder Map` and `Relationship Gaps` headings.
5. End with the exact heading `Evidence boundary`, followed by the boundary below.

## Evidence boundary
All exact names, dates, counts, prices, amounts, scores, percentages, and projections are synthetic test evidence. The response is read-only decision support. Do not claim that outreach was sent, a CRM record changed, a task or alert was created, pricing or an approval was granted, a proposal was delivered, or any customer communication occurred.

## Locked demo prompt
Map the synthetic Acme buying committee and show the relationship gaps without creating outreach tasks.

## Expected evidence marker
The response must include `Stakeholder Map`, `Relationship Gaps`, and the exact heading `Evidence boundary`.
