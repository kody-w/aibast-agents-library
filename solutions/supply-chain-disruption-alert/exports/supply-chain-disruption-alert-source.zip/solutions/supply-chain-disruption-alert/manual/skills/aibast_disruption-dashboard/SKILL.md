---
name: supply-chain-disruption-alert-disruption-dashboard
description: Use when a Customer Fulfillment Lead asks to summarize active disruption evidence.
---
# Supply Chain Disruption Alert Agent: Disruption Dashboard

## Route

Use the `disruption_dashboard` operation. The canonical persona prompt is:

> Which active disruption has the largest modeled impact and what is affected?

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `disruption_dashboard` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- DISR-002
- $3,800,000.00
- SKU-1010

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
