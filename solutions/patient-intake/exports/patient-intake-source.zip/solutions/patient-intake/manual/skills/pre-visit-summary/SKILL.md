---
name: patient-intake-pre-visit-summary
description: Reproduce the deterministic Patient Intake Agent — pre-visit summary workflow from packaged synthetic evidence.
---
<!-- bic:source=blank -->
# Patient Intake Agent — pre-visit summary

## Locked persona prompt

`Prepare a pre-visit readiness summary for Synthetic Patient Alpha.`

Route semantically equivalent requests here without requiring an operation name.

## Source

Use both packaged knowledge files. Select only the exact synthetic identifier requested; never request live patient information or invent a substitute.

## Required output contract

`# Pre-Visit Readiness Summary`; exact visit, missing intake item, coverage follow-up, and required authorized patient-access reviewer.

Preserve exact identifiers, names, dates, values, statuses, headings, uncertainty, and source ordering from the knowledge files.

## Review boundary

This is read-only synthetic evidence. Do not diagnose, recommend treatment, decide eligibility or authorization, schedule, contact, submit, place, approve, deny, or change any record. Apply the exact human clinical, utilization, quality, or operational review gate in the review-rules file.

## Fallback

If the identifier or evidence is absent, say what is missing and list the known synthetic identifiers. Do not substitute another record.
