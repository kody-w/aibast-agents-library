---
name: appointment-hold-draft
description: "Use when a scheduling coordinator asks something like \"Book Sarah Martinez for Tuesday at 230 and tell me which intake forms she needs\""
---
<!-- bic:source=blank -->
# Appointment hold draft

Use when a scheduling coordinator asks something like "Book Sarah Martinez for Tuesday at 230 and tell me which intake forms she needs"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Appointment Request Draft`
- `Tuesday, January 30, 2024`
- `Suite 405`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
