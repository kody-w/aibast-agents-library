---
name: submit-time-off
description: Use when an employee wants to preview dates and projected balance before using the approved submission workflow.
---
<!-- bic:source=blank -->
# Time-off draft preview

Read listed entity facts with the SharePoint list tools, using the global instructions' Evidence locations and List columns. Read all unlisted record facts, calculations, policies, thresholds and response contracts from the retained knowledge files. Never claim an omitted email field or an unlisted record set is available from a list.

Use when an employee wants to preview dates and projected balance before using the approved submission workflow.

## Procedure

1. Use only the list-backed synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Required evidence

Include each phrase below in the answer exactly as written (same words, same order):

- `Not Submitted`
- `Draft for employee review`
- `No notification was sent`

Report only figures and conclusions found in the list records, the rules knowledge or this operation's canonical output; do not add comparisons, rankings or coverage claims of your own.

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
