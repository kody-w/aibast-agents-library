---
name: submit-time-off
description: Use when an employee wants to preview dates and projected balance before using the approved submission workflow.
---
<!-- bic:source=blank -->
# Time-off draft preview

Use when an employee wants to preview dates and projected balance before using the approved submission workflow.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Not Submitted`
- `Draft for employee review`
- `No notification was sent`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
