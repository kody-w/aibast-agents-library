---
name: follow-up-plan
description: "Use when a service manager asks something like \"As Service Manager, the call went well and the customer accepted; what is our follow-up plan\""
---
<!-- bic:source=blank -->
# Follow up plan

Use when a service manager asks something like "As Service Manager, the call went well and the customer accepted; what is our follow-up plan"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Day 30`
- `delivery confirmation SMS`
- `Nothing has been scheduled`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
