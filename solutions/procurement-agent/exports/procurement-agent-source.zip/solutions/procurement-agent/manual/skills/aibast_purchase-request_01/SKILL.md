---
name: purchase-request
description: Use when a procurement manager asks for request context and the applicable approval level.
---
<!-- bic:source=blank -->
# Purchase-request review

Use when a procurement manager asks for request context and the applicable approval level.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `PR-5001`
- `$125,000`
- `CFO`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
