---
name: draft-rfq
description: "Use when a category buyer asks something like \"We also need an RFQ for office furniture for the same engineering team\""
---
<!-- bic:source=blank -->
# Draft rfq

Use when a category buyer asks something like "We also need an RFQ for office furniture for the same engineering team"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `RFQ-2024-FRN-0145`
- `Sustainability: 15%`
- `No RFQ was distributed`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
