# Procurement Agent solution package

| Surface | Location |
| --- | --- |
| Portable agent | `agents/@aibast-agents-library/general_stacks/procurement_agent_stack/procurement_agent.py` |
| Deployment recipe | `solutions/procurement-agent/deployment.json` |
| Approved-slide map | `solutions/procurement-agent/evals/onepager-map.json` |
| Source audit | `solutions/procurement-agent/evals/source-audit.json` |
| Strict isolated transcripts | `solutions/procurement-agent/evals/transcripts.json` |
| Persona-language cases | `tests/demo_cases/procurement-agent.json` |
| Synthetic knowledge | `solutions/procurement-agent/manual/knowledge/` |
| Uploadable skills | `solutions/procurement-agent/manual/skills/` |

## Scope

A synthetic purchasing review surface for requests, vendor evidence, approval thresholds, and spend controls that never creates a PO or commits a supplier.

Implemented operations: `purchase_request`, `vendor_comparison`, `approval_routing`, `spend_analysis`. The package contains one locked persona-language case and one uploadable skill for every exposed operation.

## Approval boundary

This package is synthetic and read-only. It does not connect to customer systems or execute external actions. Exact identifiers, dates, names, amounts, scores, and policy values are fictional evidence rather than customer outcomes. Production connections require least-privilege access, approved data handling, and a human authorization gate.

## Manual Copilot Studio preparation

Upload both Markdown files in `manual/knowledge/`, then upload the 4 `SKILL.md` files in `manual/skills/`. Bind only approved production connections after security and business-owner review. Keep the agent in Draft and stop before publish until an authorized reviewer validates every operation and guardrail.

## Current source candidate: grounding-r3

The repaired instructions, knowledge and skills are a **source-only candidate**,
not a completed native workshop. Copilot Studio skill saving and Preview were
unresponsive during the pilot. No r3 component or locked case is accepted;
installation, complete save/reopen persistence, all four fresh native cases,
reviewed screenshots and same-Draft confirmation remain required.

The superseded grounding-r3 [input inventory](evals/history/2026-10-08-pre-reshoot/manual-inputs-r3.json)
is kept as history only. The downloadable ZIP is the standard complete source
bundle for the re-shot build. Follow the current [manual tutorial](manual-tutorial.html).

Historical metadata and unchanged images remain preserved through
[the history index](evals/history/2026-08/index.json). They do not establish
current acceptance. The old native export is withheld from current import
downloads because it predates the repair. Static checks, a source commit and
staging deployment never substitute for live native evidence.

<!-- scaffold-solution-journey:start -->
## Customer journey package map

| Surface | Location |
| --- | --- |
| Customer field guide | `solutions/procurement-agent/field-guide.html` |
| Evidence report | `solutions/procurement-agent/evidence-report.html` |
| Copilot-only Easy Mode skill (default) | `skills/aibast-easy-mode-copilot/SKILL.md` |
| Optional Brainstem Easy Mode skill | `skills/aibast-easy-mode-brainstem/SKILL.md` |
| GitHub Copilot Easy-mode guide (default) | `solutions/procurement-agent/EASY-MODE-COPILOT-CHAT.md` |
| Optional Brainstem Easy-mode guide | `solutions/procurement-agent/EASY-MODE-PERSONLESS.md` |
| Guided Easy/Manual quest | `solutions/procurement-agent/quest.html` |
| Literal browser tutorial | `solutions/procurement-agent/manual-tutorial.html` |
| Raw export manifest | `solutions/procurement-agent/export-manifest.json` |
| Source bundle | `solutions/procurement-agent/exports/procurement-agent-source.zip` |
| Manual evidence | `solutions/procurement-agent/evals/manual-build-evidence.json` |
| Manual browserfilm | `solutions/procurement-agent/screenshots/manual/browserfilm.json` |
| Copilot Studio solution ZIP | `solutions/procurement-agent/exports/procurement-agent-copilot-studio-solution.zip` |
| Copilot Studio deployment settings | `solutions/procurement-agent/exports/procurement-agent-deployment-settings.json` |
| Copilot Studio export metadata | `solutions/procurement-agent/exports/procurement-agent-solution-export.json` |

**Scaffold status:** 134 resources ready; 0 pending. Manual evidence and referenced screenshots passed scaffold validation.

The journey uses synthetic inputs and qualitative proof. It is not a customer
KPI, live-system result, production-readiness claim, or publication approval.
<!-- scaffold-solution-journey:end -->
