---
name: territory-snapshot
description: "Use when a regional sales director asks something like \"Give me a snapshot of my North Valley territory\""
---
<!-- bic:source=blank -->
# Territory snapshot

Use when a sales leader asks for a territory snapshot or how the territory looks.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `$241.0M`
- `Granite Ridge`
- `Spend per recruiter`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
