---
name: contract-overview
description: "Use when a commercial attorney asks something like \"Legal just sent over the NovaTech Systems master services agreement. Can you review it before our signing meeting tomorrow\""
---
<!-- bic:source=blank -->
# Contract overview

Use when a commercial attorney asks something like "Legal just sent over the NovaTech Systems master services agreement. Can you review it before our signing meeting tomorrow"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Contract Overview`
- `6.5/10`
- `14 amendments`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
