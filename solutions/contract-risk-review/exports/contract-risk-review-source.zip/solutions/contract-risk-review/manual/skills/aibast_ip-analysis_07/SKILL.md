---
name: ip-analysis
description: "Use when a commercial attorney asks something like \"Show me the IP ownership problems in the NovaTech agreement\""
---
<!-- bic:source=blank -->
# Ip analysis

Use when a commercial attorney asks something like "Show me the IP ownership problems in the NovaTech agreement"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Section 8.2`
- `Risk Scenario`
- `License-back for client-specific work`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
