---
name: roadmap-impact
description: Use when a product trio wants a non-binding impact view with explicit validation gates.
---
<!-- bic:source=blank -->
# Roadmap review candidates

Use when a product trio wants a non-binding impact view with explicit validation gates.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.
5. End with the exact sentence `No roadmap commitment was made.`

## Deterministic pilot evidence

- `Review Candidates`
- `RBAC`
- `No roadmap commitment`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
