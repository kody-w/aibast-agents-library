---
name: beneficial-ownership
description: "Use when a compliance officer asks something like \"What about beneficial ownership on the Nexus file? We need to be compliant with FinCEN rules\""
---
<!-- bic:source=blank -->
# Beneficial ownership

Use when a compliance officer asks something like "What about beneficial ownership on the Nexus file? We need to be compliant with FinCEN rules"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Marcus Chen`
- `2 of 3 Verified`
- `67%`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
