---
name: meeting-brief
description: Use for advisor meeting preparation questions in the Wealth Insights Generator Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Advisor meeting preparation

Drafts review material and discussion prompts for licensed-advisor validation.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Wealth Advisor

Prompt: Prepare my review brief for the Kensington household without turning it into advice or outreach.

Expected synthetic evidence: George & Martha Kensington, preparation material.
