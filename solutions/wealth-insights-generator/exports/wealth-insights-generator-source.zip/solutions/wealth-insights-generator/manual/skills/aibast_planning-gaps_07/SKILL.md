---
name: planning-gaps
description: "Use when a wealth advisor asks something like \"What planning gaps does the Morrison Family have\""
---
<!-- bic:source=blank -->
# Planning gaps

Use when a wealth advisor asks something like "What planning gaps does the Morrison Family have"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Outdated (8 yrs)`
- `pre-TCJA`
- `+$48K annual fees`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
