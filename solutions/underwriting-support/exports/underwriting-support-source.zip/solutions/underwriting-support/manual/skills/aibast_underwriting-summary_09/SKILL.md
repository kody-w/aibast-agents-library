---
name: underwriting-summary
description: "Use when a senior underwriter asks something like \"Generate the complete underwriting summary for the Midwest Manufacturing submission\""
---
<!-- bic:source=blank -->
# Underwriting summary

Use when a senior underwriter asks something like "Generate the complete underwriting summary for the Midwest Manufacturing submission"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Approve with conditions`
- `$88,100`
- `drafted for you to issue`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
