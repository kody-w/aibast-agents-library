---
name: retention-actions
description: Use for retention option preparation questions in the Customer Sentiment and Churn Prediction Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Retention option preparation

Prepares reviewable service-recovery and outreach options without contacting customers or making offers.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Relationship Manager

Prompt: Prepare options for Marcus that I can review before anyone contacts him or changes a fee.

Expected synthetic evidence: Marcus Johnson, No customer was contacted.
