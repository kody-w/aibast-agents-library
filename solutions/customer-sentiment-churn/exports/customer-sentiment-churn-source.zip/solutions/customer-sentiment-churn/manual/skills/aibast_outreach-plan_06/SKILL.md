---
name: outreach-plan
description: "Use when a customer success lead asks something like \"Yes, assign the outreach and set up tracking\""
---
<!-- bic:source=blank -->
# Outreach plan

Use when a customer success lead asks something like "Yes, assign the outreach and set up tracking"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `VP Chen`
- `Escalation Rules`
- `No customer was contacted`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
