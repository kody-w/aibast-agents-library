---
name: churn-prediction
description: Use for churn-review prioritization questions in the Customer Sentiment and Churn Prediction Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Churn-review prioritization

Applies a transparent heuristic to prioritize human review without predicting an individual outcome.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Retention Specialist

Prompt: Who should my team review first today, and what evidence drove the priority?

Expected synthetic evidence: CUST-8004, prioritize review.
