---
name: maintenance-calendar
description: "Use when an operations leader asks something like \"What does the maintenance calendar look like for the next 30 days\""
---
<!-- bic:source=blank -->
# Maintenance calendar

Use when an operations leader asks something like "What does the maintenance calendar look like for the next 30 days"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Machine #12`
- `87% planned`
- `Calibration`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
