---
name: tax-impact
description: Use for illustrative tax impact questions in the Portfolio Rebalancing Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Illustrative tax impact

Shows assumptions and an illustrative gain-tax estimate for qualified professional review.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Paraplanner

Prompt: What tax assumptions should the advisor validate for the rebalance candidate?

Expected synthetic evidence: Illustrative Tax Estimate, VTI.
