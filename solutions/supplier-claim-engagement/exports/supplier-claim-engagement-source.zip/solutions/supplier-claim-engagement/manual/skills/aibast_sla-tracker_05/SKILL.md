---
name: sla-tracker
description: "Use when the team asks which claims are breached, at risk, or on track against supplier response windows."
---
# Response deadline tracker

Use when the team asks which claims are breached, at risk, or on track against supplier response windows.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `SC-05`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Breached by 2 h`
- `CLM-5203`
- `At risk`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
