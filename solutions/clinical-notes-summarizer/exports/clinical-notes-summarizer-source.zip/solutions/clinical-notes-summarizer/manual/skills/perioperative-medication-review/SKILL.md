---
name: clinical-notes-summarizer-perioperative-medication-review
description: Reproduce the deterministic Clinical Notes Agent perioperative medication review workflow, which lists source-recorded medications with the synthetic perioperative protocol flag and the floppy-iris alert.
---
<!-- bic:source=blank -->
# Clinical Notes Agent — perioperative medication review

## Locked persona prompt

`Review his medications and flag any surgical concerns.`

Route semantically equivalent requests here without requiring an operation name or an identifier; the pre-op patient is John Martinez (Patient ID / MRN 78392).

## Source

Use both packaged knowledge files and the exact reference response for this workflow.

## Required output contract

`# Medications - 12 Active`; preserve `Lisinopril 10mg daily`, `Floppy iris`, `12 Active` and every value, medication and status from the reference response.

## Review boundary

This is read-only synthetic evidence. Do not diagnose, recommend treatment, or clear the patient; the clearance decision and signature are the physician's. Never sign, file, or send the note or notify a team; protocol flags and the distribution list are drafts.
