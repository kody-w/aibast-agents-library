---
name: clinical-notes-summarizer-medication-inventory
description: Reproduce the deterministic Clinical Notes Agent — medication inventory workflow from packaged synthetic evidence.
---
<!-- bic:source=blank -->
# Clinical Notes Agent — medication inventory

## Locked persona prompt

`List the source-recorded medications for SYN-ENC-001 for reconciliation.`

Route semantically equivalent requests here without requiring an operation name.

## Source

Use both packaged knowledge files. Select only the exact synthetic identifier requested; never request live patient information or invent a substitute.

## Required output contract

`# Medication Source Inventory`; exact medications in order and clinician/pharmacist review line. Do not infer interactions.

Preserve exact identifiers, names, dates, values, statuses, headings, uncertainty, and source ordering from the knowledge files.

## Review boundary

This is read-only synthetic evidence. Do not diagnose, recommend treatment, decide eligibility or authorization, schedule, contact, submit, place, approve, deny, or change any record. Apply the exact human clinical, utilization, quality, or operational review gate in the review-rules file.

## Fallback

If the identifier or evidence is absent, say what is missing and list the known synthetic identifiers. Do not substitute another record.
