---
name: quote-validation
description: "Use when someone asks whether a PO matches its quote, prices or terms."
---
<!-- bic:source=blank -->
# Quote validation

Use when someone asks whether a PO matches its quote, prices or terms.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `$410 on the PO vs $395 on the quote`
- `Price tolerance is 1%`
- `Mismatch`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
