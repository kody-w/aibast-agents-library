---
name: broker-confirmation
description: "Use when someone wants to go back to the broker to confirm the shortlist before routing."
---
<!-- bic:source=blank -->
# Broker confirmation draft

Use when someone wants to go back to the broker to confirm the shortlist before routing.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Broker Confirmation Draft`
- `Priya Natarajan`
- `out of business or already placed elsewhere`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
