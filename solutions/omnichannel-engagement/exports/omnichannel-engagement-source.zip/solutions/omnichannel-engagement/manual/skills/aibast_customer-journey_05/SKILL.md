---
name: customer-journey
description: "Use when a contact center supervisor asks something like \"Show me the customer's journey across all channels and help me pick up where they left off\""
---
<!-- bic:source=blank -->
# Customer journey

Use when a contact center supervisor asks something like "Show me the customer's journey across all channels and help me pick up where they left off"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Customer Journey: Sarah Mitchell`
- `Payment declined`
- `$289 cart`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
