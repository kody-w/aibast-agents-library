---
name: field-service-dispatch-emergency-response
description: Use when a Emergency Duty Manager asks to prepare an approval-gated emergency response draft.
---
# Field Service Dispatch Agent: Emergency Response

## Route

Use the `emergency_response` operation. The canonical persona prompt is:

> Draft the SR-4005 response view without dispatching or notifying anyone.

## Procedure

1. Read the records with the SharePoint list tools, and the rules and controls knowledge.
2. Call or reproduce only the `emergency_response` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

Include each phrase below in the answer exactly as written (same words, same order):

- Emergency Response Draft
- Marcus Thompson
- No field action

Report only figures and conclusions found in the list records, the rules knowledge or this operation's canonical output; do not add comparisons, rankings or coverage claims of your own.

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
