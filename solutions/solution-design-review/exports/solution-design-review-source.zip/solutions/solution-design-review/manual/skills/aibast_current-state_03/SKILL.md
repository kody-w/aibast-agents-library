---
name: current-state
description: "Use when an architect asks what the current state looks like for the systems or components in scope."
---
<!-- bic:source=blank -->
# Current-state baseline

Use when an architect asks what the current state looks like for the systems or components in scope.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `CI-103`
- `End of support`
- `no current-state baseline for the Business domain`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.
